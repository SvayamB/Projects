let a = {
  x: () => this,
  y: function () {
    this.x = function () {
      return this;
    };
  },
};
let f = a.x();
let g = a.y();
let h = a.x();
a.x = function () {
  return this;
};

console.log(f, g, h, a.x());
